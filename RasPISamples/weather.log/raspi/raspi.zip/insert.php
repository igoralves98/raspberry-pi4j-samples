<?php

header('Content-type: application/json;charset=UTF-8');

// phpinfo();
/*
 * URL parms:
 *  board, sensor, type, data
 *
 *  like ?board=OlivRP1&sensor=BMP180&type=TEMPERATURE&data=27
 */

$boardID  = null;
if (!empty($_GET['board']))
{
  try
  {
    $boardID = $_GET['board'];
  }
  catch (Exception $e)
  {
    $boardID = "OlivRPi1";
  }
}
else
{
  $boardID = "OlivRPi1";
}

$sensorID = "";
if (!empty($_GET['sensor']))
{
  try
  {
    $sensorID = $_GET['sensor'];
  }
  catch (Exception $e)
  {
    $sensorID = "OOPS";
  }
}
else
{
  $sensorID = "";
}

$datatype = "";
if (!empty($_GET['type']))
{
  try
  {
    $datatype = $_GET['type'];
  }
  catch (Exception $e)
  {
    $datatype = "UNKNOWN";
  }
}

$datavalue = "0";
if (!empty($_GET['data']))
{
  try
  {
    $datavalue = $_GET['data'];
  }
  catch (Exception $e)
  {
    $datavalue = "0";
  }
}

$sessionID = "XXX";
if (!empty($_GET['session']))
{
  try
  {
    $sessionID = $_GET['session'];
  }
  catch (Exception $e)
  {
    $sessionID = "XXX";
  }
}

$comment = "";

// App logic

$username="oliv";
$password="c2h5oh";
$database="sensors";

$link = mysql_connect("mysql", $username, $password);
//$link = mysql_connect("localhost", $username, $password);
@mysql_select_db($database) or die("Unable to select database $database");


$sql = "INSERT INTO `sensor_data` (`board_id`, `sensor_id`, `session_id`, `data_type`, `data_value`, `data_comment`) "
                         ."VALUES ('$boardID', '$sensorID', '$sessionID', '$datatype', '$datavalue', '$comment')";  

$mess = "Record created";
if (!mysql_query($sql))
{
  $mess = mysql_error();
  die('Insert in DB problem: ' . $mess . '<br><a href="idform.html">Back</a>');
}

//mysql_close();
mysql_close($link);        

$response = "{  " .
            "  'ctx': { 'board': '$boardID', 'sensor': '$sensorID' }, " .
            "  'operation': { " . 
            "    '$datatype': " . $datavalue . "," .
            "    'message': '" . $mess . "'" .
            "  }" .
            "}";
echo $response;
?>