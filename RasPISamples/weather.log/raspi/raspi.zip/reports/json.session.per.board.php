<?php

header('Content-type: application/json;charset=UTF-8');

$board_id = null;

if (!empty($_GET['board']))
{
  try
  {
    $board_id = $_GET['board'];
  }
  catch (Exception $e)
  {
    $board_id = null;
  }
}

$username="oliv";
$password="c2h5oh";
$database="sensors";

$link = mysql_connect("mysql", $username, $password);
@mysql_select_db($database) or die("Unable to select database $database");

$sql = 'SELECT session_id, count(*) as "nb", min(log_time) as "min", max(log_time) as "max" '
        . ' FROM sensor_data'
        . ' WHERE board_id = "' . $board_id . '" '
        . ' GROUP BY session_id ';

$result = mysql_query($sql);
$num = mysql_numrows($result);
$i=0;

$json = '[';
$first = true;
while ($i < $num) 
{
  $id  = mysql_result($result, $i, "session_id");
  $nb  = mysql_result($result, $i, "nb");
  $min = mysql_result($result, $i, "min");
  $max = mysql_result($result, $i, "max");
  
  $json .= (($first ? '' : ', ') . '{ "session": "' . $id . '", ' . 
  	                                 '"nbrec": "'   . $nb . '", ' . 
  	                                 '"from": "'    . $min . '", ' .
  	                                 '"to": "'      . $max . '" }');
//echo $i. ' = ' . $json;
  $first = false;
  $i++;
}
$json .= ']';
mysql_close($link);        
// Return the result
echo $json;

?>        
