<?php

header('Content-type: application/json;charset=UTF-8');

$username="oliv";
$password="c2h5oh";
$database="sensors";

$link = mysql_connect("mysql", $username, $password);
@mysql_select_db($database) or die("Unable to select database $database");

$sql = 'SELECT board_id, board_comment'
        . ' FROM boards';

$result = mysql_query($sql);
$num = mysql_numrows($result);
$i=0;

$json = '[';
$first = true;
while ($i < $num) 
{
  $id      = mysql_result($result, $i, "board_id");
  $comment = mysql_result($result, $i, "board_comment");
  
  $json .= (($first ? '' : ', ') . '{ "board": "' . $id . '", "comment": "' . $comment . '" }');
//echo $i. ' = ' . $json;
  $first = false;
  $i++;
}
$json .= ']';
mysql_close($link);        
// Return the result
echo $json;

?>        
