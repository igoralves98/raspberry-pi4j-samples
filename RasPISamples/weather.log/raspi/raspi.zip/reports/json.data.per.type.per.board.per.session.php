<?php

header('Content-type: application/json;charset=UTF-8');

$type  = null;
$session_id = null;
$board_id = null;

if (!empty($_GET['type']))
{
  try
  {
    $type = $_GET['type'];
  }
  catch (Exception $e)
  {
    $type = "";
  }
}
else
{
  $type = "";
}

if (!empty($_GET['board']))
{
  try
  {
    $board_id = $_GET['board'];
  }
  catch (Exception $e)
  {
    $board_id = null;
  }
}

if (!empty($_GET['session']))
{
  try
  {
    $session_id = $_GET['session'];
  }
  catch (Exception $e)
  {
    $session_id = null;
  }
}

$username="oliv";
$password="c2h5oh";
$database="sensors";

$link = mysql_connect("mysql", $username, $password);
@mysql_select_db($database) or die("Unable to select database $database");

$sql = 'SELECT log_time, data_value'
        . ' FROM sensor_data'
        . ' WHERE data_type = "' . $type .'"';

if ($session_id != null)
{
  $sql .= (' AND session_id = "' . $session_id . '"');
}

if ($board_id != null)
{
  $sql .= (' AND board_id = "' . $board_id . '"');
}

$sql .= ' ORDER BY log_time '
        . ' ASC '; 

$result = mysql_query($sql);
$num = mysql_numrows($result);
$i=0;

$json = '[';
$first = true;
while ($i < $num) 
{
  $time  = mysql_result($result, $i, "log_time");
  $value = mysql_result($result, $i, "data_value");
  
  $json .= (($first ? '' : ', ') . '{ "time": "' . $time . '", "value": "' . $value . '" }');
//echo $i. ' = ' . $json;
  $first = false;
  $i++;
}
$json .= ']';
mysql_close($link);        
// Return the result
echo $json;

?>        
