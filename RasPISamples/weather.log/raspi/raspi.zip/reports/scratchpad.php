<!DOCTYPE html>
<?php
$type  = null;
if (!empty($_GET['type']))
{
  try
  {
    $type = $_GET['type'];
  }
  catch (Exception $e)
  {
    $type = "";
  }
}
else
{
  $type = "";
}

?>
<html>
  <head>
    <title>MySQL Scratchpad</title>
    <link rel="stylesheet" href="../print.css" type="text/css" id="styleLink">
    <script type="text/javascript">
var submitStmt = function() {
  var stmt = document.getElementById("stmt").value;
  if (stmt.trim().length > 0) {
    var url = document.location;
    url += ("?stmt=" + stmt);
    document.location.replace(url);
  }
}; 
    </script>
  </head>
  <body>
<?php
  $stmt = null;
  try
  {
    $stmt = $_GET['stmt'];
  }
  catch (Exception $e)
  {
    $stmt = "";
  }

  if ($stmt != null && strlen($stmt) > 0)
  {
    $username="oliv";
    $password="c2h5oh";
    $database="sensors";

    $link = mysql_connect("mysql", $username, $password);
    @mysql_select_db($database) or die("Unable to select database $database");

  //$sql = 'UPDATE sensor_data set session_id = "22-Dec" where session_id = "XXX" or session_id is null ';
  //$sql = 'DELETE from sensor_data where session_id = "22-Dec" or session_id = "TestFromHome" or session_id = "DEFAULT" ';

  //$stmt = 'UPDATE boards set board_comment = "This is a Raspberry PI B"';
    $sql = $stmt; // 'SELECT count(*) as "num" FROM sensor_data WHERE log_time > "2014-12-25 17:42:00" AND session_id = "2014-12-25" ';

    $result = mysql_query($sql);
    $num = mysql_numrows($result);
    echo "Returned $num row(s)<br>";

    $i=0;
    echo "<table border='1'>";
    while ($i < $num) 
    {
//    $row = mysql_result($result, $i); // , "num");
//    echo "$row <br>";
      $row = mysql_fetch_row($result); // , "num");
      echo "<tr>";
      for ($j=0; $j<count($row); $j++)
      {
        echo "<td>" . $row[$j] . "</td>";
      }
      echo "</tr>";
      $i++;
    }
    echo "</table>";

    echo "Executed:<br><pre>$sql</pre><br>";
//  echo "Returned $result<br>";
    
    $error = mysql_errno($link);
    if ($error != 0)
    {
      echo "Error " . mysql_errno($link) . ": " . mysql_error($link) . "<br>";
    }
  //$result = mysql_query("COMMIT");

  // Another SQL Statement
    /*
    $sql = 'DELETE FROM sensor_data WHERE log_time > "2014-12-25 17:42:00" AND session_id = "2014-12-25" ';

    $result = mysql_query($sql);
    echo "Executing<br><pre>$sql</pre><br>";
    echo "Returned $result<br>";
    
    $error = mysql_errno($link);
    if ($error != 0)
    {
      echo "Error " . mysql_errno($link) . ": " . mysql_error($link) . "<br>";
    }
    else
    {
      echo "Done." . "<br>";
    }
    */
    mysql_free_result($result);
    mysql_close($link);     
  } 
  /* 
  else
  {
    echo "Enter your SQL statement";
  }  
  */
?>        
    <p>
      Enter an SQL statement:<br>
      <textarea id="stmt" rows="4" cols="80"></textarea>
      <br>
      <button onclick="submitStmt();">Execute</button>
    </p>
  </body>        
</html>
